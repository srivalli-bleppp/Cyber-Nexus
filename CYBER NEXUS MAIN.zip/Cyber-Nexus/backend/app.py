import os
import uuid
from datetime import datetime

from flask import Flask, jsonify, request
from flask_cors import CORS
from dotenv import load_dotenv
from openai import OpenAI

try:
    from backend.database import get_connection, init_database
except ModuleNotFoundError:
    from database import get_connection, init_database


load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

app = Flask(__name__)

# Ensure the SQLite schema exists before serving requests.
init_database()
CORS(app)




def get_ai_client():
    api_key = os.getenv("FEATHERLESS_API_KEY")
    if not api_key or api_key == "PASTE_YOUR_FEATHERLESS_API_KEY_HERE":
        raise RuntimeError("FEATHERLESS_API_KEY is not configured in backend/.env")
    return OpenAI(
        base_url="https://api.featherless.ai/v1",
        api_key=api_key
    )



@app.route("/", methods=["GET"])
def home():
    return jsonify({
        "message": "Cyber-Nexus backend is running!"
    })



@app.route("/test-ai", methods=["GET"])
def test_ai():

    response = get_ai_client().chat.completions.create(
        model="deepseek-ai/DeepSeek-V3.2",
        messages=[
            {
                "role": "user",
                "content": "Say hello to Cyber-Nexus!"
            }
        ],
        max_tokens=100
    )

    return jsonify({
        "response": response.choices[0].message.content
    })



@app.route("/chat", methods=["POST"])
def chat():

    data = request.get_json()

    if not data or "message" not in data:
        return jsonify({
            "error": "Missing 'message' in request body"
        }), 400

    user_message = data["message"]

    response = get_ai_client().chat.completions.create(
        model="deepseek-ai/DeepSeek-V3.2",
        messages=[
            {
                "role": "user",
                "content": user_message
            }
        ],
        max_tokens=500
    )

    return jsonify({
        "response": response.choices[0].message.content
    })




def extract_recommendation(analysis):
    """Extract the AI recommendation line while preserving the full AI response."""
    import re

    match = re.search(r"(?im)^Recommendation:\s*(.+)$", analysis or "")
    if match:
        return match.group(1).strip()
    return (analysis or "").strip()


def get_user(user_id):
    connection = get_connection()
    user = connection.execute(
        "SELECT user_id, username, role, status FROM users WHERE user_id = ?",
        (user_id,)
    ).fetchone()
    connection.close()
    return user


def require_security_admin(user_id):
    """Return a security-admin row or an appropriate API error response."""
    if not user_id:
        return None, (jsonify({"error": "reviewer_id is required"}), 400)

    user = get_user(user_id)
    if not user:
        return None, (jsonify({"error": "Reviewer not found"}), 404)

    if user["status"] != "active":
        return None, (jsonify({"error": "Reviewer is inactive"}), 403)

    if user["role"] != "security_admin":
        return None, (jsonify({"error": "Only security_admin users can approve or reject AI recommendations"}), 403)

    return user, None


@app.route("/analyze", methods=["POST"])
def analyze():

    import os
    import joblib
    import pandas as pd

    data = request.get_json()

    if not data or "event" not in data or "user_id" not in data:
        return jsonify({
            "error": "Missing 'event' or 'user_id' in request body"
        }), 400

    security_event = data["event"]
    user_id = data["user_id"]

    

    ml_result = None

    if "features" in data:

        model_path = os.path.join(
            os.path.dirname(os.path.dirname(__file__)),
            "ml",
            "severity_model.pkl"
        )

        if not os.path.exists(model_path):
            return jsonify({
                "error": "Trained severity model not found"
            }), 404

        try:
            model = joblib.load(model_path)

            input_data = pd.DataFrame([data["features"]])

            prediction = model.predict(input_data)[0]

            ml_result = str(prediction)

        except Exception as e:
            return jsonify({
                "error": "ML prediction failed",
                "message": str(e)
            }), 400

    
    response = get_ai_client().chat.completions.create(
        model="deepseek-ai/DeepSeek-V3.2",
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a cybersecurity analysis assistant for Cyber-Nexus. "
                    "Analyze the security event provided by the user. "
                    "Return your answer using exactly this format:\n\n"
                    "Threat Level: LOW, MEDIUM, HIGH, or CRITICAL\n"
                    "Confidence: a number between 0 and 1\n"
                    "Indicators: a short list of suspicious indicators\n"
                    "Recommendation: a practical defensive action\n\n"
                    "Keep the response concise and defensive. "
                    "Do not provide instructions for carrying out attacks."
                )
            },
            {
                "role": "user",
                "content": security_event
            }
        ],
        max_tokens=300
    )

    ai_result = response.choices[0].message.content


    connection = get_connection()

    cursor = connection.execute(
        """
        INSERT INTO security_events
        (user_id, event, analysis)
        VALUES (?, ?, ?)
        """,
        (user_id, security_event, ai_result)
    )
    event_id = cursor.lastrowid

    recommendation = extract_recommendation(ai_result)
    approval_id = "APR-" + uuid.uuid4().hex[:8].upper()

    connection.execute(
        """
        INSERT INTO approval_requests
        (approval_id, event_id, user_id, recommendation, analysis, status)
        VALUES (?, ?, ?, ?, ?, 'PENDING')
        """,
        (approval_id, event_id, user_id, recommendation, ai_result)
    )

    connection.commit()
    connection.close()

    result = {
        "event": security_event,
        "analysis": ai_result,
        "event_id": event_id,
        "approval": {
            "approval_id": approval_id,
            "status": "PENDING",
            "recommendation": recommendation
        }
    }

    if ml_result is not None:
        result["ml_prediction"] = {
            "severity": ml_result,
            "model": "RandomForestClassifier"
        }

    return jsonify(result)


@app.route("/approvals", methods=["GET"])
def get_approvals():
    """Return AI recommendations awaiting or previously given human review."""
    status = (request.args.get("status") or "").strip().upper()
    allowed_statuses = {"PENDING", "APPROVED", "REJECTED"}

    if status and status not in allowed_statuses:
        return jsonify({
            "error": "Invalid status",
            "allowed": sorted(allowed_statuses)
        }), 400

    connection = get_connection()
    query = """
        SELECT
            a.approval_id,
            a.event_id,
            a.user_id,
            u.username,
            a.recommendation,
            a.analysis,
            a.status,
            a.reviewer_id,
            reviewer.username AS reviewer_username,
            a.review_note,
            a.created_at,
            a.reviewed_at,
            se.event
        FROM approval_requests a
        LEFT JOIN users u ON a.user_id = u.user_id
        LEFT JOIN users reviewer ON a.reviewer_id = reviewer.user_id
        LEFT JOIN security_events se ON a.event_id = se.id
    """
    params = []
    if status:
        query += " WHERE a.status = ?"
        params.append(status)
    query += " ORDER BY a.created_at DESC"

    approvals = connection.execute(query, params).fetchall()
    connection.close()

    return jsonify([dict(approval) for approval in approvals])


@app.route("/approvals/<approval_id>", methods=["GET"])
def get_approval(approval_id):
    connection = get_connection()
    approval = connection.execute(
        """
        SELECT
            a.approval_id,
            a.event_id,
            a.user_id,
            u.username,
            u.role,
            a.recommendation,
            a.analysis,
            a.status,
            a.reviewer_id,
            reviewer.username AS reviewer_username,
            a.review_note,
            a.created_at,
            a.reviewed_at,
            se.event
        FROM approval_requests a
        LEFT JOIN users u ON a.user_id = u.user_id
        LEFT JOIN users reviewer ON a.reviewer_id = reviewer.user_id
        LEFT JOIN security_events se ON a.event_id = se.id
        WHERE a.approval_id = ?
        """,
        (approval_id,)
    ).fetchone()
    connection.close()

    if not approval:
        return jsonify({"error": "Approval request not found"}), 404

    return jsonify(dict(approval))


@app.route("/approvals/<approval_id>/decision", methods=["POST"])
def decide_approval(approval_id):
    data = request.get_json(silent=True) or {}
    decision = str(data.get("decision", "")).strip().upper()
    reviewer_id = data.get("reviewer_id")
    review_note = str(data.get("review_note", "")).strip()

    if decision not in {"APPROVED", "REJECTED"}:
        return jsonify({
            "error": "decision must be APPROVED or REJECTED"
        }), 400

    reviewer, error_response = require_security_admin(reviewer_id)
    if error_response:
        return error_response

    connection = get_connection()
    approval = connection.execute(
        "SELECT approval_id, status FROM approval_requests WHERE approval_id = ?",
        (approval_id,)
    ).fetchone()

    if not approval:
        connection.close()
        return jsonify({"error": "Approval request not found"}), 404

    if approval["status"] != "PENDING":
        connection.close()
        return jsonify({
            "error": "Approval request has already been reviewed",
            "status": approval["status"]
        }), 409

    reviewed_at = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    connection.execute(
        """
        UPDATE approval_requests
        SET status = ?, reviewer_id = ?, review_note = ?, reviewed_at = ?
        WHERE approval_id = ? AND status = 'PENDING'
        """,
        (decision, reviewer["user_id"], review_note or None, reviewed_at, approval_id)
    )
    connection.commit()

    updated = connection.execute(
        """
        SELECT
            a.approval_id,
            a.event_id,
            a.user_id,
            u.username,
            a.recommendation,
            a.analysis,
            a.status,
            a.reviewer_id,
            reviewer.username AS reviewer_username,
            a.review_note,
            a.created_at,
            a.reviewed_at,
            se.event
        FROM approval_requests a
        LEFT JOIN users u ON a.user_id = u.user_id
        LEFT JOIN users reviewer ON a.reviewer_id = reviewer.user_id
        LEFT JOIN security_events se ON a.event_id = se.id
        WHERE a.approval_id = ?
        """,
        (approval_id,)
    ).fetchone()
    connection.close()

    return jsonify({
        "message": f"AI recommendation {decision.lower()} successfully",
        "approval": dict(updated)
    })


@app.route("/events", methods=["GET"])
def get_events():

    connection = get_connection()

    events = connection.execute(
        """
        SELECT
            security_events.id,
            security_events.user_id,
            users.username,
            users.role,
            security_events.event,
            security_events.analysis,
            security_events.created_at
        FROM security_events
        LEFT JOIN users
            ON security_events.user_id = users.user_id
        ORDER BY security_events.created_at DESC
        """
    ).fetchall()

    connection.close()

    return jsonify([
        dict(event)
        for event in events
    ])



@app.route("/users/<user_id>/events", methods=["GET"])
def get_user_events(user_id):

    connection = get_connection()

    user = connection.execute(
        """
        SELECT
            user_id,
            username,
            role,
            status
        FROM users
        WHERE user_id = ?
        """,
        (user_id,)
    ).fetchone()

    if not user:
        connection.close()

        return jsonify({
            "error": "User not found"
        }), 404

    events = connection.execute(
        """
        SELECT
            id,
            user_id,
            event,
            analysis,
            created_at
        FROM security_events
        WHERE user_id = ?
        ORDER BY created_at DESC
        """,
        (user_id,)
    ).fetchall()

    connection.close()

    return jsonify({
        "user": dict(user),
        "events": [
            dict(event)
            for event in events
        ]
    })



@app.route("/stats", methods=["GET"])
def get_stats():

    connection = get_connection()

    total_events = connection.execute(
        "SELECT COUNT(*) FROM security_events"
    ).fetchone()[0]

    medium_events = connection.execute(
        """
        SELECT COUNT(*)
        FROM security_events
        WHERE analysis LIKE '%MEDIUM%'
        """
    ).fetchone()[0]

    high_events = connection.execute(
        """
        SELECT COUNT(*)
        FROM security_events
        WHERE analysis LIKE '%HIGH%'
        """
    ).fetchone()[0]

    critical_events = connection.execute(
        """
        SELECT COUNT(*)
        FROM security_events
        WHERE analysis LIKE '%CRITICAL%'
        """
    ).fetchone()[0]

    low_events = connection.execute(
        """
        SELECT COUNT(*)
        FROM security_events
        WHERE analysis LIKE '%LOW%'
        """
    ).fetchone()[0]

    connection.close()

    return jsonify({
        "total_events": total_events,
        "low": low_events,
        "medium": medium_events,
        "high": high_events,
        "critical": critical_events
    })



@app.route("/users", methods=["GET"])
def get_users():

    connection = get_connection()

    users = connection.execute(
        """
        SELECT
            user_id,
            username,
            role,
            status
        FROM users
        """
    ).fetchall()

    connection.close()

    return jsonify([
        dict(user)
        for user in users
    ])



@app.route("/login", methods=["POST"])
def login():

    data = request.get_json()

    if not data or "username" not in data:
        return jsonify({
            "error": "Username is required"
        }), 400

    username = data["username"]

    connection = get_connection()

    user = connection.execute(
        """
        SELECT
            user_id,
            username,
            role,
            status
        FROM users
        WHERE username = ?
        """,
        (username,)
    ).fetchone()

    connection.close()

    if not user:
        return jsonify({
            "error": "User not found"
        }), 404

    if user["status"] != "active":
        return jsonify({
            "error": "User is inactive"
        }), 403

    return jsonify({
        "message": "Login successful",
        "user": dict(user)
    })



@app.route("/investigate/<user_id>", methods=["POST"])
def investigate(user_id):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT user_id, username, role, status FROM users WHERE user_id = ?",
        (user_id,)
    )
    user = cursor.fetchone()

    if not user:
        conn.close()
        return jsonify({"error": "User not found"}), 404

    cursor.execute(
        """
        SELECT id, user_id, event, analysis, created_at
        FROM security_events
        WHERE user_id = ?
        ORDER BY created_at DESC
        """,
        (user_id,)
    )
    events = cursor.fetchall()

    risk_score = 0

    for event in events:
        analysis = (event["analysis"] or "").upper()

        if "CRITICAL" in analysis:
            risk_score += 40
        elif "HIGH" in analysis:
            risk_score += 30
        elif "MEDIUM" in analysis:
            risk_score += 20
        elif "LOW" in analysis:
            risk_score += 5

    risk_score = min(risk_score, 100)

    if risk_score >= 70:
        severity = "CRITICAL"
    elif risk_score >= 45:
        severity = "HIGH"
    elif risk_score >= 20:
        severity = "MEDIUM"
    else:
        severity = "LOW"

    incident_id = "INC-" + uuid.uuid4().hex[:8].upper()

    cursor.execute(
        """
        INSERT INTO incidents
        (incident_id, user_id, risk_score, severity, status)
        VALUES (?, ?, ?, ?, ?)
        """,
        (incident_id, user_id, risk_score, severity, "OPEN")
    )

    conn.commit()
    conn.close()

    return jsonify({
        "incident_id": incident_id,
        "user_id": user_id,
        "risk_score": risk_score,
        "severity": severity,
        "status": "OPEN",
        "event_count": len(events)
    }), 201


@app.route("/incidents", methods=["GET"])
def get_incidents():

    connection = get_connection()

    incidents = connection.execute(
        """
        SELECT
            incidents.incident_id,
            incidents.user_id,
            users.username,
            users.role,
            incidents.risk_score,
            incidents.severity,
            incidents.status
        FROM incidents
        LEFT JOIN users
            ON incidents.user_id = users.user_id
        ORDER BY incidents.rowid DESC
        """
    ).fetchall()

    connection.close()

    return jsonify([
        dict(incident)
        for incident in incidents
    ])



@app.route("/incidents/<incident_id>", methods=["GET"])
def get_incident(incident_id):

    connection = get_connection()


    incident = connection.execute(
        """
        SELECT
            incidents.incident_id,
            incidents.user_id,
            incidents.risk_score,
            incidents.severity,
            incidents.status,

            users.username,
            users.role,
            users.status AS user_status

        FROM incidents

        LEFT JOIN users
            ON incidents.user_id = users.user_id

        WHERE incidents.incident_id = ?
        """,
        (incident_id,)
    ).fetchone()

    if not incident:
        connection.close()

        return jsonify({
            "error": "Incident not found"
        }), 404

    incident = dict(incident)


    events = connection.execute(
        """
        SELECT
            id,
            user_id,
            event,
            analysis,
            created_at
        FROM security_events
        WHERE user_id = ?
        ORDER BY created_at ASC
        """,
        (incident["user_id"],)
    ).fetchall()

    events = [
        dict(event)
        for event in events
    ]

    connection.close()


    ai_analysis = []

    for event in events:

        ai_analysis.append({
            "event_id": event["id"],
            "analysis": event["analysis"],
            "created_at": event["created_at"]
        })


    return jsonify({

        "incident": {
            "incident_id": incident["incident_id"],
            "status": incident["status"]
        },

        "user": {
            "user_id": incident["user_id"],
            "username": incident["username"],
            "role": incident["role"],
            "status": incident["user_status"]
        },

        "risk": {
            "score": incident["risk_score"],
            "level": incident["severity"]
        },

        "severity": {
            "level": incident["severity"]
        },

        "events": events,

        "ai_analysis": ai_analysis
    })
@app.route("/dataset/status", methods=["GET"])
def dataset_status():
    import os
    import pandas as pd

    dataset_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        "dataset",
        "cyber_investigation_master_10000.csv"
    )

    if not os.path.exists(dataset_path):
        return {
            "status": "error",
            "message": "Dataset not found",
            "path": dataset_path
        }, 404

    df = pd.read_csv(dataset_path)

    return {
        "status": "loaded",
        "dataset": "cyber_investigation_master_10000.csv",
        "rows": len(df),
        "columns": len(df.columns),
        "column_names": list(df.columns)
    }
@app.route("/dataset/sample", methods=["GET"])
def dataset_sample():
    import os
    import pandas as pd

    dataset_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        "dataset",
        "cyber_investigation_master_10000.csv"
    )

    if not os.path.exists(dataset_path):
        return {
            "status": "error",
            "message": "Dataset not found"
        }, 404

    df = pd.read_csv(dataset_path)

    return {
        "status": "success",
        "rows_returned": 5,
        "data": df.head(5).to_dict(orient="records")
    }
@app.route("/ml/predict", methods=["POST"])
def ml_predict():
    import os
    import joblib
    import pandas as pd

    model_path = os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        "ml",
        "severity_model.pkl"
    )

    if not os.path.exists(model_path):
        return jsonify({
            "error": "Trained severity model not found"
        }), 404

    data = request.get_json()

    if not data:
        return jsonify({
            "error": "Request body is required"
        }), 400

    try:
        model = joblib.load(model_path)

        input_data = pd.DataFrame([data])

        prediction = model.predict(input_data)[0]

        return jsonify({
            "status": "success",
            "predicted_severity": str(prediction)
        })

    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 400


if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        debug=False,
        port=8000
    )