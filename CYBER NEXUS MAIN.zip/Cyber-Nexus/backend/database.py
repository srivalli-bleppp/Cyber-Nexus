import os
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.abspath(os.path.join(BASE_DIR, "..", "cybernexus.db"))


def get_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_database():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id TEXT PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            role TEXT NOT NULL,
            status TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS security_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            event TEXT NOT NULL,
            analysis TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS events (
            event_id TEXT PRIMARY KEY,
            user_id TEXT,
            timestamp TEXT,
            source TEXT,
            host TEXT,
            event_type TEXT,
            src_ip TEXT,
            message TEXT,
            process TEXT,
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS incidents (
            incident_id TEXT PRIMARY KEY,
            user_id TEXT,
            risk_score INTEGER,
            severity TEXT,
            status TEXT
        )
    """)

    # Human-in-the-loop approval queue for AI recommendations.
    # This is additive and safe for existing databases.
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS approval_requests (
            approval_id TEXT PRIMARY KEY,
            event_id INTEGER NOT NULL,
            user_id TEXT NOT NULL,
            recommendation TEXT NOT NULL,
            analysis TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'PENDING',
            reviewer_id TEXT,
            review_note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            reviewed_at TIMESTAMP,
            FOREIGN KEY (event_id) REFERENCES security_events(id),
            FOREIGN KEY (user_id) REFERENCES users(user_id),
            FOREIGN KEY (reviewer_id) REFERENCES users(user_id)
        )
    """)

    demo_users = [
        ("U001", "arjun", "employee", "active"),
        ("U002", "rahul", "employee", "active"),
        ("U003", "priya", "employee", "active"),
        ("A001", "admin", "security_admin", "active"),
    ]

    cursor.executemany("""
        INSERT OR IGNORE INTO users (user_id, username, role, status)
        VALUES (?, ?, ?, ?)
    """, demo_users)

    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_database()
    print("Database initialized successfully!")
