import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  Activity, 
  Database, 
  Users, 
  AlertTriangle, 
  Search, 
  Bell, 
  Settings,
  ChevronRight,
  Server,
  Lock,
  Cpu,
  Plus,
  Mail,
  User,
  Terminal,
  Network,
  Bot,
  Plug,
  Layers,
  CheckCircle2,
  XCircle,
  Clock3
} from 'lucide-react';

const initialInvestigations = [
  { id: 'INV-3091', title: 'Suspicious Lateral Movement', source: 'Internal Subnet 10.0.4.x', target: 'HR Database', type: 'Intrusion', severity: 'Critical', status: 'Open', date: '2026-09-04' },
  { id: 'INV-3090', title: 'Unauthorized API Access', source: 'IP 185.199.108.x (RU)', target: 'Billing API', type: 'Data Exfiltration', severity: 'High', status: 'Investigating', date: '2026-09-04' },
  { id: 'INV-3088', title: 'Phishing Campaign Detected', source: 'domain: secure-login-update.com', target: 'Employee Emails', type: 'Email Sec', severity: 'Medium', status: 'Resolved', date: '2026-09-03' },
  { id: 'INV-3085', title: 'Ransomware Payload Blocked', source: 'email attachment: invoice.pdf.exe', target: 'Endpoint Workstation', type: 'Malware', severity: 'High', status: 'Closed', date: '2026-09-01' },
  { id: 'INV-3082', title: 'Abnormal Admin Login', source: 'VPN Node (Singapore)', target: 'Admin Portal', type: 'IAM', severity: 'Low', status: 'Open', date: '2026-08-29' },
];

const initialUsers = [
  { id: 'USR-001', name: 'Alice Chen', role: 'Security Analyst L2', email: 'alice.c@cybernexus.com', status: 'Active', lastLogin: '2 mins ago' },
  { id: 'USR-002', name: 'Bob Smith', role: 'System Admin', email: 'bob.s@cybernexus.com', status: 'Active', lastLogin: '1 hour ago' },
  { id: 'USR-003', name: 'Charlie Davis', role: 'Incident Responder', email: 'charlie.d@cybernexus.com', status: 'Inactive', lastLogin: '5 days ago' },
  { id: 'USR-004', name: 'Diana Prince', role: 'Threat Hunter', email: 'diana.p@cybernexus.com', status: 'Active', lastLogin: '10 mins ago' },
  { id: 'USR-005', name: 'Ethan Hunt', role: 'Security Engineer', email: 'ethan.h@cybernexus.com', status: 'Active', lastLogin: '30 mins ago' },
];

const mlMetrics = {
  totalRecordsProcessed: 10000,
  anomalyDetectionAccuracy: 98.4,
  activeModels: 3,
  lastTrainingRun: '2 hours ago',
  threatsMitigated: 142
};

const SeverityBadge = ({ severity }) => {
  const styles = {
    Critical: 'bg-red-100 text-red-800 border-red-300',
    High: 'bg-orange-100 text-orange-800 border-orange-300',
    Medium: 'bg-amber-100 text-amber-800 border-amber-300',
    Low: 'bg-slate-100 text-slate-700 border-slate-300',
  };
  return (
    <span className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${styles[severity] || styles.Low}`}>
      {severity}
    </span>
  );
};

const StatusBadge = ({ status }) => {
  const styles = {
    Open: 'bg-red-50 text-red-700 border-red-200',
    Investigating: 'bg-blue-50 text-blue-700 border-blue-200',
    Resolved: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    Closed: 'bg-slate-100 text-slate-600 border-slate-200'
  };
  return (
    <span className={`px-2 py-0.5 rounded text-[11px] font-medium border ${styles[status] || styles.Open}`}>
      {status}
    </span>
  );
};

const AdminPortalView = () => {
  const [systemLogs] = useState([
    { id: 'LOG-9921', level: 'INFO', message: 'Firewall rules updated successfully by Bob Smith', timestamp: '2026-09-05 02:14:10' },
    { id: 'LOG-9920', level: 'WARN', message: 'High memory usage detected on node cluster us-east-1', timestamp: '2026-09-05 01:55:00' },
    { id: 'LOG-9919', level: 'ERROR', message: 'Failed authentication attempt from IP 45.33.32.156', timestamp: '2026-09-05 01:12:44' },
    { id: 'LOG-9918', level: 'INFO', message: 'Database backup completed with 0 errors', timestamp: '2026-09-05 00:00:05' },
  ]);

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded p-4 flex justify-between items-center shadow-sm">
        <div>
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Lock className="w-4 h-4 text-orange-600" />
            Admin Portal Control Plane
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">High-privilege system controls, security auditing, and server configurations.</p>
        </div>
        <span className="px-2.5 py-1 bg-orange-50 text-orange-700 border border-orange-200 text-xs font-mono rounded">
          Level 5 Access
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded p-4 shadow-sm">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">Cluster Status</h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Core Services</span>
              <span className="text-emerald-600 font-mono font-medium">Operational (12/12)</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-100">
              <span className="text-slate-500">Encryption Keys</span>
              <span className="text-slate-800 font-mono">Rotated (24h ago)</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-500">Zero-Trust Gateway</span>
              <span className="text-emerald-600 font-mono font-medium">Enforced</span>
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded p-4 shadow-sm">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">Global Policies</h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between items-center py-1 border-b border-slate-100">
              <span className="text-slate-500">Strict MFA Enforcement</span>
              <span className="px-1.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded text-[10px] font-semibold">ENABLED</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-slate-100">
              <span className="text-slate-500">Automated Quarantine</span>
              <span className="px-1.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded text-[10px] font-semibold">ENABLED</span>
            </div>
            <div className="flex justify-between items-center py-1">
              <span className="text-slate-500">Debug Telemetry</span>
              <span className="px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded text-[10px] font-semibold">DISABLED</span>
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded p-4 shadow-sm">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">Quick Actions</h3>
          <div className="space-y-2">
            <button onClick={() => alert('All caches flushed successfully across 12 edge nodes.')} className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded text-xs font-medium transition-colors">
              Flush Global Caches
            </button>
            <button onClick={() => alert('Security audit report compiled and exported to secure storage.')} className="w-full py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded text-xs font-medium transition-colors">
              Generate Audit Snapshot
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded p-4 shadow-sm">
        <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">Privileged Event Audit Log</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-600">
                <th className="px-3 py-2 border-b border-slate-200 font-semibold">Log ID</th>
                <th className="px-3 py-2 border-b border-slate-200 font-semibold">Level</th>
                <th className="px-3 py-2 border-b border-slate-200 font-semibold">Message</th>
                <th className="px-3 py-2 border-b border-slate-200 font-semibold text-right">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono">
              {systemLogs.map(l => (
                <tr key={l.id} className="hover:bg-slate-50">
                  <td className="px-3 py-2.5 text-slate-800">{l.id}</td>
                  <td className="px-3 py-2.5">
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${l.level === 'ERROR' ? 'bg-red-50 text-red-700 border border-red-200' : l.level === 'WARN' ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-blue-50 text-blue-700 border border-blue-200'}`}>
                      {l.level}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-slate-700 font-sans">{l.message}</td>
                  <td className="px-3 py-2.5 text-right text-slate-500">{l.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const UserAppView = () => {
  const [userMessages, setUserMessages] = useState([
    { id: 1, sender: 'Security Desk', text: 'Please ensure your VPN credentials are updated before Monday.', time: 'Yesterday' },
    { id: 2, sender: 'IT Helpdesk', text: 'Your request for software license [IDE-Pro] has been approved.', time: '3 days ago' },
  ]);
  const [newMessage, setNewMessage] = useState('');

  const handleSend = (e) => {
    e.preventDefault();
    if(newMessage) {
      setUserMessages([{ id: Date.now(), sender: 'You', text: newMessage, time: 'Just now' }, ...userMessages]);
      setNewMessage('');
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded p-4 flex justify-between items-center shadow-sm">
        <div>
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <User className="w-4 h-4 text-blue-600" />
            User Portal & Employee Workspace
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">Standard employee security dashboard and IT service desk communication channel.</p>
        </div>
        <span className="px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-200 text-xs font-mono rounded">
          Status: Verified
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white border border-slate-200 rounded p-4 shadow-sm flex flex-col">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">Security Checklist</h3>
          <div className="space-y-2.5 text-xs">
            <div className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded">
              <span className="text-slate-700 font-medium">Password Last Changed</span>
              <span className="text-emerald-600 font-mono font-semibold">14 days ago (Valid)</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded">
              <span className="text-slate-700 font-medium">Hardware Security Key (FIDO2)</span>
              <span className="text-emerald-600 font-mono font-semibold">Connected</span>
            </div>
            <div className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded">
              <span className="text-slate-700 font-medium">Phishing Simulation Score</span>
              <span className="text-blue-600 font-mono font-semibold">100% (Passed)</span>
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded p-4 shadow-sm flex flex-col">
          <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">IT & Security Messages</h3>
          <div className="space-y-2 mb-3 flex-1 overflow-y-auto max-h-40">
            {userMessages.map(m => (
              <div key={m.id} className="p-2.5 bg-slate-50 border border-slate-200 rounded">
                <div className="flex justify-between text-[10px] text-slate-500 mb-1">
                  <span className="font-bold text-slate-800">{m.sender}</span>
                  <span>{m.time}</span>
                </div>
                <p className="text-xs text-slate-700">{m.text}</p>
              </div>
            ))}
          </div>
          <form onSubmit={handleSend} className="flex gap-2">
            <input type="text" placeholder="Message security desk..." value={newMessage} onChange={e=>setNewMessage(e.target.value)} className="flex-1 bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600" />
            <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded text-xs font-medium transition-colors">Send</button>
          </form>
        </div>
      </div>
    </div>
  );
};

const ApprovalStatusBadge = ({ status }) => {
  const styles = {
    PENDING: 'bg-amber-50 text-amber-700 border-amber-200',
    APPROVED: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    REJECTED: 'bg-red-50 text-red-700 border-red-200'
  };
  return (
    <span className={`px-2 py-0.5 rounded text-[11px] font-semibold border ${styles[status] || 'bg-slate-50 text-slate-600 border-slate-200'}`}>
      {status}
    </span>
  );
};

const ApprovalsView = ({ approvals, setApprovals }) => {
  const [statusFilter, setStatusFilter] = useState('PENDING');
  const [selected, setSelected] = useState(null);
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const filtered = approvals.filter((item) => !statusFilter || item.status === statusFilter);
  const pendingCount = approvals.filter((item) => item.status === 'PENDING').length;

  const review = async (decision) => {
    if (!selected) return;
    setSubmitting(true);
    setError('');
    try {
      const response = await fetch(`/api/approvals/${selected.approval_id}/decision`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          decision,
          reviewer_id: 'A001',
          review_note: note
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Unable to submit review');

      setApprovals((current) => current.map((item) =>
        item.approval_id === selected.approval_id ? data.approval : item
      ));
      setSelected(null);
      setNote('');
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded p-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Bot className="w-4 h-4 text-blue-600" />
              Human Approval Queue
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Review AI recommendations before they are accepted as an analyst decision.</p>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-amber-50 text-amber-700 border border-amber-200 rounded text-xs font-mono">
              {pendingCount} Pending
            </span>
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-700 focus:outline-none focus:border-blue-600">
              <option value="PENDING">Pending</option>
              <option value="APPROVED">Approved</option>
              <option value="REJECTED">Rejected</option>
              <option value="">All</option>
            </select>
          </div>
        </div>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded p-3 text-xs">{error}</div>
      )}

      <div className="bg-white border border-slate-200 rounded shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[900px] text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-xs font-bold text-slate-600">Request</th>
                <th className="px-4 py-3 text-xs font-bold text-slate-600">Security Event</th>
                <th className="px-4 py-3 text-xs font-bold text-slate-600">AI Recommendation</th>
                <th className="px-4 py-3 text-xs font-bold text-slate-600">Status</th>
                <th className="px-4 py-3 text-right"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((item) => (
                <tr key={item.approval_id} className="hover:bg-slate-50">
                  <td className="px-4 py-3 align-top">
                    <span className="font-mono text-xs font-bold text-slate-800">{item.approval_id}</span>
                    <p className="text-[10px] text-slate-500 mt-1">Event #{item.event_id}</p>
                  </td>
                  <td className="px-4 py-3 align-top max-w-[260px]">
                    <p className="text-xs font-semibold text-slate-900 truncate">{item.event || 'Security event'}</p>
                    <p className="text-[10px] text-slate-500 mt-1">User: {item.username || item.user_id}</p>
                  </td>
                  <td className="px-4 py-3 align-top max-w-[360px]">
                    <p className="text-xs text-slate-700 line-clamp-2">{item.recommendation}</p>
                  </td>
                  <td className="px-4 py-3 align-top"><ApprovalStatusBadge status={item.status} /></td>
                  <td className="px-4 py-3 align-top text-right">
                    <button onClick={() => { setSelected(item); setNote(''); setError(''); }} className="px-2.5 py-1.5 border border-slate-300 hover:border-blue-400 hover:text-blue-700 rounded text-xs font-semibold text-slate-700">
                      {item.status === 'PENDING' ? 'Review' : 'View'}
                    </button>
                  </td>
                </tr>
              ))}
              {!filtered.length && (
                <tr><td colSpan="5" className="px-4 py-12 text-center text-sm text-slate-500">No approval requests in this view.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {selected && (
        <div className="fixed inset-0 z-50 bg-slate-900/30 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl bg-white rounded-lg shadow-xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-slate-900">AI Recommendation Review</h3>
                  <ApprovalStatusBadge status={selected.status} />
                </div>
                <p className="text-[11px] text-slate-500 font-mono mt-1">{selected.approval_id}</p>
              </div>
              <button onClick={() => setSelected(null)} className="p-1.5 text-slate-400 hover:text-slate-700 rounded"><XCircle className="w-4 h-4" /></button>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <p className="text-[10px] uppercase tracking-wider font-bold text-slate-500 mb-1.5">Security Event</p>
                <div className="bg-slate-50 border border-slate-200 rounded p-3 text-xs text-slate-700 whitespace-pre-wrap">{selected.event}</div>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider font-bold text-slate-500 mb-1.5">AI Recommendation</p>
                <div className="bg-blue-50/60 border border-blue-200 rounded p-3 text-xs text-slate-800">{selected.recommendation}</div>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider font-bold text-slate-500 mb-1.5">Full AI Analysis</p>
                <pre className="bg-slate-900 text-slate-100 rounded p-3 text-[11px] leading-5 whitespace-pre-wrap font-mono">{selected.analysis}</pre>
              </div>
              {selected.status === 'PENDING' ? (
                <>
                  <div>
                    <label className="text-[10px] uppercase tracking-wider font-bold text-slate-500">Reviewer Note (optional)</label>
                    <textarea value={note} onChange={(e) => setNote(e.target.value)} rows="3" placeholder="Explain why you approved or rejected this recommendation..." className="mt-1.5 w-full border border-slate-300 rounded p-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600" />
                  </div>
                  <div className="flex justify-end gap-2 pt-1">
                    <button disabled={submitting} onClick={() => review('REJECTED')} className="px-3 py-2 bg-white border border-red-300 text-red-700 hover:bg-red-50 rounded text-xs font-semibold flex items-center gap-1.5 disabled:opacity-50"><XCircle className="w-3.5 h-3.5" /> Reject</button>
                    <button disabled={submitting} onClick={() => review('APPROVED')} className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-semibold flex items-center gap-1.5 disabled:opacity-50"><CheckCircle2 className="w-3.5 h-3.5" /> {submitting ? 'Saving...' : 'Approve'}</button>
                  </div>
                </>
              ) : (
                <div className="bg-slate-50 border border-slate-200 rounded p-3 text-xs text-slate-600">
                  Reviewed by <span className="font-semibold text-slate-800">{selected.reviewer_username || selected.reviewer_id || 'Security Admin'}</span>{selected.reviewed_at ? ` on ${selected.reviewed_at}` : ''}.
                  {selected.review_note && <div className="mt-1 text-slate-700">Note: {selected.review_note}</div>}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const DashboardView = ({ setActiveTab, investigations, stats, datasetStatus }) => (
  <div className="space-y-4">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {[
        { title: 'Active Threats', value: investigations.filter(i => i.status === 'Open').length.toString(), icon: AlertTriangle },
        { title: 'Ongoing Cases', value: investigations.filter(i => i.status === 'Investigating').length.toString(), icon: Shield },
        { title: 'ML Anomalies', value: (stats?.high || stats?.critical || mlMetrics.threatsMitigated).toString(), icon: Activity },
        { title: 'System Health', value: '99.9%', icon: Server },
      ].map((stat, i) => (
        <div key={i} className="bg-white p-4 border border-slate-200 rounded shadow-sm flex items-start justify-between">
          <div>
            <p className="text-xs font-medium text-slate-500 mb-1">{stat.title}</p>
            <h3 className="text-xl font-bold text-slate-900">{stat.value}</h3>
          </div>
          <div className="p-2 bg-slate-50 border border-slate-200 rounded text-slate-600">
            <stat.icon className="w-4 h-4" />
          </div>
        </div>
      ))}
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <div className="lg:col-span-2 bg-white rounded border border-slate-200 shadow-sm flex flex-col h-full">
        <div className="flex justify-between items-center p-4 border-b border-slate-200">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-slate-600" />
            Recent Investigations
          </h2>
          <button onClick={() => setActiveTab('investigations')} className="text-xs font-semibold text-blue-600 hover:text-blue-700 transition-colors">View All</button>
        </div>
        <div className="p-0 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-2.5 text-xs font-bold text-slate-600 border-b border-slate-200">ID / Title</th>
                <th className="px-4 py-2.5 text-xs font-bold text-slate-600 border-b border-slate-200">Source</th>
                <th className="px-4 py-2.5 text-xs font-bold text-slate-600 border-b border-slate-200 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {investigations.slice(0, 5).map((inv) => (
                <tr key={inv.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => setActiveTab('investigations')}>
                  <td className="px-4 py-3">
                    <div className="font-semibold text-slate-900">{inv.title}</div>
                    <div className="text-xs text-slate-500 mt-0.5 font-mono">{inv.id} • {inv.type}</div>
                  </td>
                  <td className="px-4 py-3 text-xs font-mono text-slate-600">{inv.source}</td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex flex-col items-end gap-1.5">
                      <SeverityBadge severity={inv.severity} />
                      <StatusBadge status={inv.status} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="bg-white rounded border border-slate-200 shadow-sm p-4 flex flex-col">
        <h2 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Cpu className="w-4 h-4 text-slate-600" />
          ML Engine Status
        </h2>
        <div className="space-y-4 flex-1">
          <div>
            <div className="flex justify-between text-xs mb-1.5 font-medium">
              <span className="text-slate-600">Dataset Processing</span>
              <span className="text-slate-900 font-mono">{(datasetStatus?.rows || mlMetrics.totalRecordsProcessed).toLocaleString()}</span>
            </div>
            <div className="w-full bg-slate-100 rounded-sm h-1.5 border border-slate-200">
              <div className="bg-blue-600 h-full rounded-sm w-full"></div>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1.5 font-medium">
              <span className="text-slate-600">Detection Accuracy</span>
              <span className="text-slate-900 font-mono">{mlMetrics.anomalyDetectionAccuracy}%</span>
            </div>
            <div className="w-full bg-slate-100 rounded-sm h-1.5 border border-slate-200">
              <div className="bg-blue-600 h-full rounded-sm" style={{ width: '98.4%' }}></div>
            </div>
          </div>
          <div className="pt-4 mt-2 border-t border-slate-200 grid grid-cols-2 gap-3">
            <div className="bg-slate-50 p-2.5 border border-slate-200 rounded text-center">
              <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Active Models</p>
              <p className="text-lg font-mono font-bold text-slate-900 mt-1">{datasetStatus?.status === 'loaded' ? 1 : mlMetrics.activeModels}</p>
            </div>
            <div className="bg-slate-50 p-2.5 border border-slate-200 rounded text-center">
              <p className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">Last Run</p>
              <p className="text-xs font-mono font-medium text-slate-800 mt-2">{mlMetrics.lastTrainingRun}</p>
            </div>
          </div>
          <button onClick={() => setActiveTab('mcp')} className="w-full py-2 mt-auto bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded text-xs font-medium transition-colors">
            Manage Models
          </button>
        </div>
      </div>
    </div>
  </div>
);

const InvestigationsView = ({ investigations, setInvestigations }) => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const filtered = investigations.filter(i => 
    i.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    i.source.toLowerCase().includes(searchTerm.toLowerCase()) ||
    i.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-white border border-slate-200 rounded shadow-sm flex flex-col h-[calc(100vh-6rem)]">
      <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-4 bg-slate-50">
        <div>
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Database className="w-4 h-4 text-slate-600" />
            Investigations Database
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">Central log and forensic attack vector repository.</p>
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search ID, title, source..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-3 py-1.5 bg-white border border-slate-300 rounded text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-600 w-full shadow-sm"
            />
          </div>
          <button 
            onClick={() => {
              const newId = `INV-${Math.floor(Math.random() * 1000) + 3000}`;
              setInvestigations([{
                id: newId, title: 'New Suspicious Activity', source: 'IP 203.0.113.195', target: 'External Gateway', type: 'Intrusion', severity: 'Medium', status: 'Open', date: new Date().toISOString().split('T')[0]
              }, ...investigations])
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" /> New Case
          </button>
        </div>
      </div>
      
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-left border-collapse min-w-[800px] text-sm">
          <thead>
            <tr className="bg-slate-100/70 sticky top-0 border-b border-slate-200">
              <th className="px-4 py-3 text-xs font-bold text-slate-600">ID & Type</th>
              <th className="px-4 py-3 text-xs font-bold text-slate-600">Incident Details</th>
              <th className="px-4 py-3 text-xs font-bold text-slate-600">Source / Target Website</th>
              <th className="px-4 py-3 text-xs font-bold text-slate-600">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map((inv) => (
              <tr key={inv.id} className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-3.5 align-top">
                  <span className="text-xs font-mono font-bold text-slate-800 block">{inv.id}</span>
                  <span className="text-[11px] text-slate-500 mt-0.5 block">{inv.type}</span>
                </td>
                <td className="px-4 py-3.5 align-top">
                  <p className="text-sm font-semibold text-slate-900">{inv.title}</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">{inv.date}</p>
                </td>
                <td className="px-4 py-3.5 align-top">
                  <div className="flex flex-col gap-1 text-xs">
                    <span className="text-slate-700 font-mono bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 inline-block w-fit">Src: {inv.source}</span>
                    <span className="text-slate-500">Dst: {inv.target}</span>
                  </div>
                </td>
                <td className="px-4 py-3.5 align-top">
                  <div className="flex flex-col items-start gap-1.5">
                    <SeverityBadge severity={inv.severity} />
                    <StatusBadge status={inv.status} />
                  </div>
                </td>
                <td className="px-4 py-3.5 align-top text-right">
                  <button className="p-1 text-slate-400 hover:text-slate-700 rounded transition-colors">
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan="5" className="px-4 py-12 text-center text-sm text-slate-500">
                  No records found matching "{searchTerm}".
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const UserDirectoryView = ({ users, setUsers }) => {
  const [showAddUser, setShowAddUser] = useState(false);
  const [newUser, setNewUser] = useState({ name: '', role: '', email: '' });

  const handleAddUser = (e) => {
    e.preventDefault();
    if(newUser.name && newUser.email) {
      const id = `USR-${String(users.length + 1).padStart(3, '0')}`;
      setUsers([...users, { ...newUser, id, status: 'Active', lastLogin: 'Just now' }]);
      setNewUser({ name: '', role: '', email: '' });
      setShowAddUser(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded p-4 flex justify-between items-center shadow-sm">
        <div>
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Users className="w-4 h-4 text-slate-600" />
            IAM Directory & Users
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">Manage personnel permissions and identity records.</p>
        </div>
        <button 
          onClick={() => setShowAddUser(!showAddUser)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1.5 shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" /> Add User
        </button>
      </div>

      {showAddUser && (
        <div className="bg-white border border-slate-200 rounded p-4 shadow-sm">
          <h3 className="text-xs font-bold text-slate-700 mb-3 uppercase tracking-wider">Provision Identity</h3>
          <form onSubmit={handleAddUser} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
             <div>
               <label className="block text-[11px] font-bold text-slate-600 mb-1">Full Name</label>
               <input type="text" required value={newUser.name} onChange={e=>setNewUser({...newUser, name: e.target.value})} className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600" placeholder="Jane Doe" />
             </div>
             <div>
               <label className="block text-[11px] font-bold text-slate-600 mb-1">Email</label>
               <input type="email" required value={newUser.email} onChange={e=>setNewUser({...newUser, email: e.target.value})} className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600" placeholder="jane@cybernexus.com" />
             </div>
             <div>
               <label className="block text-[11px] font-bold text-slate-600 mb-1">Role</label>
               <select required value={newUser.role} onChange={e=>setNewUser({...newUser, role: e.target.value})} className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600">
                 <option value="" disabled>Select Role...</option>
                 <option value="Security Analyst">Security Analyst</option>
                 <option value="System Admin">System Admin</option>
                 <option value="Read-Only Viewer">Read-Only Viewer</option>
               </select>
             </div>
             <div className="sm:col-span-3 flex justify-end gap-2 mt-1">
               <button type="button" onClick={() => setShowAddUser(false)} className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 transition-colors">Cancel</button>
               <button type="submit" className="bg-blue-600 text-white px-3 py-1.5 rounded text-xs font-medium hover:bg-blue-700 transition-colors shadow-sm">Provision User</button>
             </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {users.map((user) => (
          <div key={user.id} className="bg-white border border-slate-200 rounded p-4 shadow-sm flex flex-col">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded bg-slate-100 flex items-center justify-center text-slate-700 text-xs font-bold border border-slate-200">
                  {user.name.charAt(0)}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{user.name}</h4>
                  <p className="text-[11px] text-slate-500 font-mono">{user.id}</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold tracking-wide uppercase border ${user.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                {user.status}
              </span>
            </div>
            
            <div className="space-y-1.5 mt-auto text-xs">
              <div className="flex items-center gap-2 text-slate-600 font-medium">
                <Shield className="w-3.5 h-3.5 text-slate-400" /> {user.role}
              </div>
              <div className="flex items-center gap-2 text-slate-600">
                <Mail className="w-3.5 h-3.5 text-slate-400" /> <span className="truncate">{user.email}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-500 pt-3 mt-3 border-t border-slate-100">
                <span className="font-mono text-[11px]">Last login: {user.lastLogin}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const McpView = () => {
  const [models, setModels] = useState([
    { id: 'MOD-001', name: 'Gemini Threat Analyzer', provider: 'Google', status: 'Connected', resources: 12, tools: 24 },
    { id: 'MOD-002', name: 'LogHeuristic-Llama', provider: 'Local Host', status: 'Disconnected', resources: 4, tools: 5 }
  ]);
  const [showAdd, setShowAdd] = useState(false);
  const [newModel, setNewModel] = useState({ name: '', provider: '', endpoint: '' });

  const handleAddModel = (e) => {
    e.preventDefault();
    if (newModel.name) {
      setModels([...models, { 
        id: `MOD-${String(models.length + 1).padStart(3, '0')}`, 
        ...newModel, 
        status: 'Connected', 
        resources: Math.floor(Math.random() * 10) + 1, 
        tools: Math.floor(Math.random() * 20) + 5 
      }]);
      setNewModel({ name: '', provider: '', endpoint: '' });
      setShowAdd(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-slate-200 rounded p-4 flex justify-between items-center shadow-sm">
        <div>
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Network className="w-4 h-4 text-slate-600" />
            Model Context Protocol (MCP) Engine
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">Integrate external large language models and context servers.</p>
        </div>
        <button 
          onClick={() => setShowAdd(!showAdd)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1.5 shadow-sm"
        >
          <Plus className="w-3.5 h-3.5" /> Connect Model
        </button>
      </div>

      {showAdd && (
        <div className="bg-white border border-slate-200 rounded p-4 shadow-sm">
          <h3 className="text-xs font-bold text-slate-700 mb-3 uppercase tracking-wider">Register External Model</h3>
          <form onSubmit={handleAddModel} className="grid grid-cols-1 sm:grid-cols-3 gap-4">
             <div>
               <label className="block text-[11px] font-bold text-slate-600 mb-1">Model Name</label>
               <input type="text" required value={newModel.name} onChange={e=>setNewModel({...newModel, name: e.target.value})} className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600" placeholder="Nexus Sentinel" />
             </div>
             <div>
               <label className="block text-[11px] font-bold text-slate-600 mb-1">Provider</label>
               <select required value={newModel.provider} onChange={e=>setNewModel({...newModel, provider: e.target.value})} className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600">
                 <option value="" disabled>Select Provider...</option>
                 <option value="Google (Gemini)">Google (Gemini)</option>
                 <option value="Anthropic (Claude)">Anthropic (Claude)</option>
                 <option value="OpenAI">OpenAI</option>
                 <option value="Local Hosted">Local Hosted</option>
               </select>
             </div>
             <div>
               <label className="block text-[11px] font-bold text-slate-600 mb-1">Endpoint (Optional)</label>
               <input type="text" value={newModel.endpoint} onChange={e=>setNewModel({...newModel, endpoint: e.target.value})} className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600" placeholder="ws://localhost:8080/mcp" />
             </div>
             <div className="sm:col-span-3 flex justify-end gap-2 mt-1">
               <button type="button" onClick={() => setShowAdd(false)} className="px-3 py-1.5 text-xs text-slate-600 hover:text-slate-900 transition-colors">Cancel</button>
               <button type="submit" className="bg-blue-600 text-white px-3 py-1.5 rounded text-xs font-medium hover:bg-blue-700 transition-colors shadow-sm">Connect Model</button>
             </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {models.map((model) => (
          <div key={model.id} className="bg-white border border-slate-200 rounded p-4 shadow-sm flex flex-col">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-slate-100 border border-slate-200 rounded text-slate-700">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{model.name}</h4>
                  <p className="text-[11px] text-slate-500 font-mono">{model.provider} • {model.id}</p>
                </div>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold tracking-wide uppercase border ${model.status === 'Connected' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                {model.status}
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-3 mt-auto">
              <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
                <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-600 mb-1">
                  <Layers className="w-3.5 h-3.5" /> Resources
                </div>
                <p className="text-sm font-mono font-bold text-slate-900">{model.resources}</p>
              </div>
              <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
                <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-600 mb-1">
                  <Plug className="w-3.5 h-3.5" /> Tools
                </div>
                <p className="text-sm font-mono font-bold text-slate-900">{model.tools}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function CyberNexusApp() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isLoaded, setIsLoaded] = useState(false);
  
  const [investigations, setInvestigations] = useState(initialInvestigations);
  const [users, setUsers] = useState(initialUsers);
  const [stats, setStats] = useState(null);
  const [datasetStatus, setDatasetStatus] = useState(null);
  const [backendStatus, setBackendStatus] = useState('Connecting...');
  const [approvals, setApprovals] = useState([]);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 300);

    const loadBackendData = async () => {
      try {
        const health = await fetch('/api/');
        if (!health.ok) throw new Error('Backend unavailable');
        setBackendStatus('Connected');

        const [eventsRes, usersRes, statsRes, datasetRes, approvalsRes] = await Promise.all([
          fetch('/api/events'),
          fetch('/api/users'),
          fetch('/api/stats'),
          fetch('/api/dataset/status'),
          fetch('/api/approvals')
        ]);

        if (eventsRes.ok) {
          const events = await eventsRes.json();
          const mapped = events.map((event) => {
            const analysis = (event.analysis || '').toUpperCase();
            const severity = analysis.includes('CRITICAL') ? 'Critical' : analysis.includes('HIGH') ? 'High' : analysis.includes('MEDIUM') ? 'Medium' : 'Low';
            return {
              id: `EVT-${event.id}`,
              title: event.event || 'Security Event',
              source: event.username ? `user: ${event.username}` : 'Security Event',
              target: 'Cyber-Nexus',
              type: 'AI Analysis',
              severity,
              status: 'Open',
              date: event.created_at ? event.created_at.split(' ')[0] : new Date().toISOString().split('T')[0]
            };
          });
          if (mapped.length) setInvestigations(mapped);
        }

        if (usersRes.ok) {
          const apiUsers = await usersRes.json();
          if (Array.isArray(apiUsers) && apiUsers.length) {
            setUsers(apiUsers.map((u) => ({
              id: u.user_id,
              name: u.username,
              role: u.role,
              email: `${u.username}@nexus.local`,
              status: u.status === 'active' ? 'Active' : 'Inactive',
              lastLogin: 'Backend managed'
            })));
          }
        }

        if (statsRes.ok) setStats(await statsRes.json());
        if (datasetRes.ok) setDatasetStatus(await datasetRes.json());
        if (approvalsRes.ok) setApprovals(await approvalsRes.json());
      } catch (error) {
        setBackendStatus('Offline');
      }
    };

    loadBackendData();
    return () => clearTimeout(timer);
  }, []);

  const navItems = [
    { id: 'dashboard', label: 'Overview', icon: Activity },
    { id: 'investigations', label: 'Investigations Db', icon: Database },
    { id: 'approvals', label: 'AI Approvals', icon: CheckCircle2 },
    { id: 'mcp', label: 'MCP Engine', icon: Network },
    { id: 'users', label: 'IAM Directory', icon: Users },
  ];

  if (!isLoaded) return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center gap-3">
      <div className="w-6 h-6 border-2 border-slate-300 border-t-blue-600 rounded-full animate-spin"></div>
      <p className="text-slate-500 text-xs uppercase tracking-widest font-bold">Loading Enterprise Environment</p>
    </div>
  );

  return (
    <div className="flex h-screen bg-slate-100 font-sans text-slate-800 overflow-hidden">
      
      {/* Sidebar Navigation */}
      <aside className="w-60 bg-white border-r border-slate-200 flex flex-col flex-shrink-0 z-20 shadow-sm">
        <div className="h-14 flex items-center px-4 border-b border-slate-200">
          <div className="flex items-center gap-2.5 text-slate-900">
            <div className="w-6 h-6 rounded bg-blue-600 flex items-center justify-center shadow-sm">
              <Shield className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-sm font-bold tracking-tight">CyberNexus</span>
          </div>
        </div>
        
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          <div className="px-3 mb-2 mt-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            Core Modules
          </div>
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded text-xs font-semibold transition-colors ${
                activeTab === item.id 
                  ? 'bg-blue-50 text-blue-700 border border-blue-200/60 shadow-sm' 
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </button>
          ))}
          
          <div className="px-3 mt-6 mb-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            External Systems
          </div>
          <button onClick={() => setActiveTab('adminPortal')} className={`w-full flex items-center justify-between px-3 py-2 rounded text-xs font-semibold transition-colors group ${activeTab === 'adminPortal' ? 'bg-blue-50 text-blue-700 border border-blue-200/60 shadow-sm' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}`}>
            <div className="flex items-center gap-2.5">
              <Lock className="w-4 h-4" /> Admin Portal
            </div>
            <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-slate-400" />
          </button>
          <button onClick={() => setActiveTab('userApp')} className={`w-full flex items-center justify-between px-3 py-2 rounded text-xs font-semibold transition-colors group ${activeTab === 'userApp' ? 'bg-blue-50 text-blue-700 border border-blue-200/60 shadow-sm' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}`}>
            <div className="flex items-center gap-2.5">
              <User className="w-4 h-4" /> User App
            </div>
            <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity text-slate-400" />
          </button>
        </nav>

        <div className="p-3 border-t border-slate-200 bg-slate-50/50">
          <button onClick={() => setActiveTab('settings')} className="w-full flex items-center gap-2.5 p-2 rounded hover:bg-slate-100 transition-colors text-left">
            <div className="w-7 h-7 rounded bg-slate-200 flex items-center justify-center text-slate-700 text-[10px] font-bold border border-slate-300">
              AD
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-800 truncate">System Admin</p>
              <p className="text-[10px] text-slate-500 truncate font-mono">root@nexus</p>
            </div>
            <Settings className="w-3.5 h-3.5 text-slate-400" />
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        
        {/* Top Header */}
        <header className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-6 flex-shrink-0 shadow-sm">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600">
              <div className={`w-2 h-2 rounded-full ${backendStatus === 'Connected' ? 'bg-emerald-500' : 'bg-amber-500'}`}></div>
              {backendStatus === 'Connected' ? 'DB Connected' : 'Backend Connecting'}
            </span>
            <span className="text-slate-300">|</span>
            <span className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600">
              <div className={`w-2 h-2 rounded-full ${datasetStatus?.status === 'loaded' ? 'bg-blue-600' : 'bg-slate-400'}`}></div>
              {datasetStatus?.status === 'loaded' ? 'ML Active' : 'ML Loading'}
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button className="relative p-1.5 hover:bg-slate-100 rounded text-slate-600 transition-colors">
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-blue-600 rounded-full border border-white"></span>
            </button>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-100">
          <div className="max-w-7xl mx-auto h-full">
            {activeTab === 'dashboard' && <DashboardView setActiveTab={setActiveTab} investigations={investigations} stats={stats} datasetStatus={datasetStatus} />}
            {activeTab === 'investigations' && <InvestigationsView investigations={investigations} setInvestigations={setInvestigations} />}
            {activeTab === 'approvals' && <ApprovalsView approvals={approvals} setApprovals={setApprovals} />}
            {activeTab === 'users' && <UserDirectoryView users={users} setUsers={setUsers} />}
            {activeTab === 'mcp' && <McpView />}
            {activeTab === 'adminPortal' && <AdminPortalView />}
            {activeTab === 'userApp' && <UserAppView />}
            
            {activeTab === 'settings' && (
              <div className="flex flex-col items-center justify-center h-64 bg-white border border-slate-200 rounded shadow-sm">
                <Settings className="w-8 h-8 text-slate-400 mb-3" />
                <h2 className="text-sm font-bold text-slate-800 mb-1">System Settings</h2>
                <p className="text-xs text-slate-500">Platform configuration module placeholder.</p>
              </div>
            )}
          </div>
        </div>
        
      </main>
    </div>
  );
}