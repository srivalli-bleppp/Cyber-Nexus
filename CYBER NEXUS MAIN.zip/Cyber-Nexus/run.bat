@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ==========================================
echo          CYBER-NEXUS STARTUP
echo ==========================================

where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python was not found.
  echo Install Python 3.11+ and make sure "python" works in CMD.
  pause
  exit /b 1
)

where npm >nul 2>&1
if errorlevel 1 (
  echo ERROR: Node.js/npm was not found.
  echo Install Node.js LTS and restart CMD.
  pause
  exit /b 1
)

if not exist "backend\.venv\Scripts\python.exe" (
  echo Creating Python virtual environment...
  python -m venv "backend\.venv"
  if errorlevel 1 goto :error
)

call "backend\.venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r "backend\requirements.txt"
if errorlevel 1 goto :error

if not exist "backend\.env" (
  copy /Y "backend\.env.example" "backend\.env" >nul
  echo.
  echo NOTE: backend\.env was created.
  echo Add your Featherless API key there to enable the DeepSeek AI agent.
)

echo.
echo Installing/checking frontend packages...
pushd "frontend"
call npm install
if errorlevel 1 (
  echo.
  echo npm install failed. Retrying with legacy peer dependency resolution...
  call npm install --legacy-peer-deps
  if errorlevel 1 (
    popd
    goto :error
  )
)
popd

echo.
echo Starting Flask backend...
start "Cyber-Nexus Backend" cmd /k "cd /d "%~dp0" && call "backend\.venv\Scripts\activate.bat" && python "backend\app.py""

echo Starting React frontend...
start "Cyber-Nexus Frontend" cmd /k "cd /d "%~dp0frontend" && npm run dev -- --host 127.0.0.1"

timeout /t 5 /nobreak >nul
start "" "http://127.0.0.1:5173"

echo.
echo ==========================================
echo Frontend: http://127.0.0.1:5173
echo Backend : http://127.0.0.1:8000
echo ==========================================
echo.
endlocal
exit /b 0

:error
echo.
echo Startup failed. Read the error above.
pause
endlocal
exit /b 1
