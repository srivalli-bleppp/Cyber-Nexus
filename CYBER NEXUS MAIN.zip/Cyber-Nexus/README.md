# Cyber-Nexus — Connected Frontend + Backend

This package keeps the supplied Cyber-Nexus React/Tailwind interface and connects it to the supplied Flask backend.

## Run

Double-click `run.bat`.

It starts:
- React/Vite frontend: http://127.0.0.1:5173
- Flask backend: http://127.0.0.1:8000

The frontend proxies `/api/*` to the Flask backend, so browser CORS issues are avoided.

## AI / ML

The supplied `ml/severity_model.pkl` is included and is loaded by the backend for `/ml/predict` and `/analyze` when feature data is supplied.

The Featherless DeepSeek agent used by `/chat` and `/analyze` requires a valid API key in `backend/.env`:

`FEATHERLESS_API_KEY=...`

Never commit the real API key to GitHub.

## Important

The model was saved with scikit-learn 1.9.x, so the included requirements pin `scikit-learn==1.9.0` for compatibility.
